
Title: Scalper_v9.3 	Currency Pairs: All      

Timeframe: M1		    Lots Size: 0.1
			
TakeProfit: 3		    StopLoss: 0

Trading Time:	17:00 to 07:00 GMT

Best Results With: EUR/USD, USD/CAD, USD/CHF, EUR/CHF  

Compatibility:	Only MT4

Note: Put kernl32.dll file on libraries folder. 


By Inputs tab you can change some settings.

Lots:                    You can change the lot size according to your account balance.
TakeProfit:              You can change take profit 3 to whatever you want.
StopLoss:                You can change stop loss 0 to  whatever you want.
OpenHoura:               You can change trading, start timing.
CloseHoura:              You can change trading stop timing.
MaxBuy:                  You can change the buy traders daily session (OpenHoura to CloseHours) limit.
MaxSell:                 You can change the sell traders daily session (OpenHoura to CloseHours) limit. 
 